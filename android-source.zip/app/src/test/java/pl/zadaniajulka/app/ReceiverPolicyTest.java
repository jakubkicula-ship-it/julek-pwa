package pl.zadaniajulka.app;
import org.junit.Test;
import static org.junit.Assert.*;
public class ReceiverPolicyTest {
 @Test public void boundPhoneRemainsChildReceiverAfterLogoutOrPanelChange(){assertEquals("Julek",ReceiverPolicy.role(true,""));assertEquals("Julek",ReceiverPolicy.role(true,"Kuba"));assertEquals("Julek",ReceiverPolicy.role(true,"Marlena"));}
 @Test public void ordinaryInstallationFollowsSelectedPanel(){assertEquals("",ReceiverPolicy.role(false,""));assertEquals("Kuba",ReceiverPolicy.role(false,"Kuba"));}
}
