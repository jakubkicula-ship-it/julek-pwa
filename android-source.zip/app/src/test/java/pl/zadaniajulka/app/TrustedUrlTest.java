package pl.zadaniajulka.app;
import org.junit.Test;
import static org.junit.Assert.*;
public class TrustedUrlTest {
 @Test public void onlyThisApplicationReceivesTheNativeBridge(){assertTrue(TrustedUrl.app("https://jakubkicula-ship-it.github.io/julek-pwa/"));assertTrue(TrustedUrl.app("https://jakubkicula-ship-it.github.io/julek-pwa/?guardianInvite=x"));assertFalse(TrustedUrl.app("http://jakubkicula-ship-it.github.io/julek-pwa/"));assertFalse(TrustedUrl.app("https://jakubkicula-ship-it.github.io/other-app/"));assertFalse(TrustedUrl.app("https://jakubkicula-ship-it.github.io.evil.test/julek-pwa/"));assertFalse(TrustedUrl.app("https://evil@jakubkicula-ship-it.github.io/julek-pwa/"));assertFalse(TrustedUrl.app("https://jakubkicula-ship-it.github.io/julek-pwa/../other/"));assertFalse(TrustedUrl.app("https://jakubkicula-ship-it.github.io/julek-pwa/%2e%2e/other/"));assertFalse(TrustedUrl.app("file:///julek-pwa/"));}
}
