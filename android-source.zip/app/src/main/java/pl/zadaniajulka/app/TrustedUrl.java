package pl.zadaniajulka.app;
import java.net.URI;
final class TrustedUrl {
 static boolean app(String value){try{URI u=URI.create(value);return "https".equals(u.getScheme())&&"jakubkicula-ship-it.github.io".equals(u.getHost())&&(u.getPort()==-1||u.getPort()==443)&&u.getUserInfo()==null&&u.normalize().getPath().startsWith("/julek-pwa/")&&!java.util.Arrays.asList(u.getPath().split("/")).contains("..");}catch(Exception e){return false;}}
}
