package pl.zadaniajulka.app;
import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;
import android.webkit.*;
import android.widget.Toast;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONObject;
import org.json.JSONArray;
import java.lang.ref.WeakReference;
public class MainActivity extends Activity {
 private WebView web;private static WeakReference<MainActivity> current=new WeakReference<>(null);private boolean foreground;
 static void refresh(){MainActivity a=current.get();if(a!=null)a.runOnUiThread(()->{if(a.web!=null)a.web.evaluateJavascript("window.dispatchEvent(new Event('julek-native-change'))",null);});}
 static void showCurrentAlert(){MainActivity a=current.get();if(a!=null&&a.foreground)a.runOnUiThread(()->a.startActivity(new Intent(a,AlarmActivity.class)));}
 @Override public void onCreate(Bundle saved){super.onCreate(saved);current=new WeakReference<>(this);Notifier.channels(this);NativeStore.id(this);NativeStore.secret(this);web=new WebView(this);WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);settings.setGeolocationEnabled(false);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);if(BuildConfig.DEBUG)WebView.setWebContentsDebuggingEnabled(true);web.addJavascriptInterface(new Bridge(),"JulekAndroid");web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){String url=request.getUrl().toString();if(TrustedUrl.app(url))return false;Uri u=request.getUrl();if("https".equals(u.getScheme())||"mailto".equals(u.getScheme()))try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}return true;}});setContentView(web);web.loadUrl("https://jakubkicula-ship-it.github.io/julek-pwa/");FirebaseMessaging.getInstance().getToken().addOnSuccessListener(token->{NativeStore.prefs(this).edit().putString("fcm",token).commit();SyncJob.schedule(this);});if(!NativeStore.prefs(this).getBoolean("intro",false)){NativeStore.prefs(this).edit().putBoolean("intro",true).apply();new AlertDialog.Builder(this).setTitle("Alarmy w Zadaniach Julka").setMessage("Aby przypomnienia dzwoniły także przy zamkniętym oknie, zezwól na powiadomienia i alarm pełnoekranowy. Potem wybierz swój panel. Każde przypomnienie potwierdzasz przyciskiem Odebrałem.").setPositiveButton("Włącz",(d,w)->permissions()).setNegativeButton("Później",null).show();}}
 private boolean allowed(){return Build.VERSION.SDK_INT<33||checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;}
 private boolean fullScreen(){return Build.VERSION.SDK_INT<34||Notifier.manager(this).canUseFullScreenIntent();}
 private void permissions(){if(Build.VERSION.SDK_INT>=33&&!allowed()){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},33);return;}if(Build.VERSION.SDK_INT>=34&&!fullScreen())new AlertDialog.Builder(this).setTitle("Zezwól na alarm pełnoekranowy").setMessage("Na następnym ekranie włącz zgodę dla Zadania Julka. Dzięki niej Android może pokazać przypomnienie na zablokowanym ekranie.").setPositiveButton("Otwórz zgodę",(d,w)->startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,Uri.parse("package:"+getPackageName())))).setNegativeButton("Później",null).show();else Toast.makeText(this,"Powiadomienia alarmowe są włączone.",Toast.LENGTH_LONG).show();}
 @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results){super.onRequestPermissionsResult(code,permissions,results);if(code==33&&allowed())permissions();refresh();}
 @Override protected void onResume(){super.onResume();foreground=true;refresh();if(NativeStore.first(this)!=null)showCurrentAlert();}
 @Override protected void onPause(){foreground=false;super.onPause();}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
 private boolean trusted(){return web!=null&&TrustedUrl.app(web.getUrl());}
 final class Bridge {
  @JavascriptInterface public String getStatus(){try{JSONArray ids=new JSONArray();java.util.Iterator<String> it=NativeStore.object(MainActivity.this,"received").keys();while(it.hasNext())ids.put(it.next());return new JSONObject().put("alarmsEnabled",NativeStore.enabled(MainActivity.this)).put("notificationsEnabled",NativeStore.prefs(MainActivity.this).getBoolean("notifications",true)).put("notificationsAllowed",allowed()).put("fullScreenAllowed",fullScreen()).put("acknowledgedIds",ids).put("version","3.0 Beta").toString();}catch(Exception e){return "{}";}}
  @JavascriptInterface public void syncSession(String data){runOnUiThread(()->{if(trusted())NativeStore.session(MainActivity.this,data);});}
  @JavascriptInterface public void setAlarmEnabled(boolean value){runOnUiThread(()->{if(!trusted())return;NativeStore.prefs(MainActivity.this).edit().putBoolean("alarms",value).commit();if(value){NativeStore.prefs(MainActivity.this).edit().putBoolean("notifications",true).commit();SyncJob.schedule(MainActivity.this);}if(NativeStore.first(MainActivity.this)!=null)AlarmService.start(MainActivity.this);refresh();});}
  @JavascriptInterface public void requestAlarmPermissions(){runOnUiThread(()->{if(trusted())permissions();});}
  @JavascriptInterface public void showReminder(String data){runOnUiThread(()->{if(!trusted())return;try{JSONObject event=new JSONObject(data);if(NativeStore.enqueue(MainActivity.this,event)){AlarmService.start(MainActivity.this);showCurrentAlert();}}catch(Exception ignored){}});}
  @JavascriptInterface public void ackFromWeb(String id){runOnUiThread(()->{if(trusted())AlarmService.acknowledge(MainActivity.this,id);});}
  @JavascriptInterface public void pushAction(String action){runOnUiThread(()->{if(!trusted())return;if("enable".equals(action)){NativeStore.prefs(MainActivity.this).edit().putBoolean("notifications",true).commit();permissions();SyncJob.schedule(MainActivity.this);}else if("disable".equals(action)){NativeStore.prefs(MainActivity.this).edit().putBoolean("notifications",false).putBoolean("alarms",false).commit();stopService(new Intent(MainActivity.this,AlarmService.class));new Thread(()->{try{NativeApi.post(NativeApi.device(MainActivity.this,"androidDisable"),"");}catch(Exception ignored){}},"julek-disable").start();}else if("test".equals(action)){new Thread(()->{try{NativeApi.register(MainActivity.this);NativeApi.post(NativeApi.device(MainActivity.this,"androidTest"),NativeApi.token(MainActivity.this));runOnUiThread(()->Toast.makeText(MainActivity.this,"Wysłano test na ten telefon.",Toast.LENGTH_LONG).show());}catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_LONG).show());}},"julek-test").start();}});}
 }
}
