package pl.zadaniajulka.app;
import android.app.Activity;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import android.animation.ValueAnimator;
import org.json.JSONObject;
public class AlarmActivity extends Activity {
 private ValueAnimator animator;private String shown="";private final Handler checker=new Handler(Looper.getMainLooper());private final Runnable refresh=()->{};
 private final Runnable check=new Runnable(){public void run(){JSONObject event=NativeStore.first(AlarmActivity.this);if(event==null){finish();return;}if(!shown.equals(event.optString("eventId")))display();checker.postDelayed(this,1000);}};
 @Override protected void onResume(){super.onResume();checker.post(check);}
 @Override protected void onPause(){checker.removeCallbacks(check);super.onPause();}
 @Override public void onCreate(Bundle saved){super.onCreate(saved);if(Build.VERSION.SDK_INT>=27){setShowWhenLocked(true);setTurnScreenOn(true);}getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED|WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);display();}
 @Override public void onNewIntent(android.content.Intent intent){super.onNewIntent(intent);display();}
 private TextView text(String value,float size,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(Color.rgb(23,61,49));t.setGravity(Gravity.CENTER);t.setPadding(8,10,8,10);if(bold)t.setTypeface(null,android.graphics.Typeface.BOLD);return t;}
 private void display(){JSONObject event=NativeStore.first(this);if(event==null){finish();return;}shown=event.optString("eventId");AlarmService.start(this);if(animator!=null)animator.cancel();LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);int padding=(int)(24*getResources().getDisplayMetrics().density);box.setPadding(padding,padding,padding,padding);box.setBackgroundColor(Color.rgb(230,241,220));box.addView(text("PRZYPOMNIENIE",16,true));box.addView(text(event.optString("topic",event.optString("body","Przypomnienie")),32,true));if(!event.optString("note").isEmpty())box.addView(text(event.optString("note"),21,false));box.addView(text("Od: "+event.optString("authorName","Rodzic"),15,false));Button received=new Button(this);received.setText("Odebrałem");received.setTextSize(25);received.setTextColor(Color.WHITE);received.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(33,87,68)));LinearLayout.LayoutParams button=new LinearLayout.LayoutParams(-1,(int)(76*getResources().getDisplayMetrics().density));button.topMargin=24;box.addView(received,button);received.setOnClickListener(v->{AlarmService.acknowledge(this,event.optString("eventId"));if(NativeStore.first(this)==null)finish();else display();});box.addView(text("Przypomnienie pozostaje do potwierdzenia.",14,false));ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.addView(box);setContentView(scroll);if(Build.VERSION.SDK_INT<26||ValueAnimator.areAnimatorsEnabled()){animator=ValueAnimator.ofArgb(Color.rgb(230,241,220),Color.rgb(255,243,207));animator.setDuration(1600);animator.setRepeatCount(ValueAnimator.INFINITE);animator.setRepeatMode(ValueAnimator.REVERSE);animator.addUpdateListener(a->box.setBackgroundColor((Integer)a.getAnimatedValue()));animator.start();}}
 @Override public void onBackPressed(){}
 @Override protected void onDestroy(){if(animator!=null)animator.cancel();super.onDestroy();}
}
