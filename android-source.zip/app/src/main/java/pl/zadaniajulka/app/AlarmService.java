package pl.zadaniajulka.app;
import android.app.*;
import android.content.*;
import android.media.*;
import android.net.Uri;
import android.os.*;
import org.json.JSONObject;
public class AlarmService extends Service {
 private MediaPlayer player;private Vibrator vibrator;private PowerManager.WakeLock lock;private String playing="";
 static void start(Context c){try{c.startForegroundService(new Intent(c,AlarmService.class));}catch(Exception e){JSONObject first=NativeStore.first(c);if(first!=null)try{Notifier.manager(c).notify(Notifier.ALARM_ID,Notifier.alarm(c,first));}catch(Exception ignored){}}}
 static void acknowledge(Context c,String id){NativeStore.received(c,id);if(NativeStore.first(c)==null){c.stopService(new Intent(c,AlarmService.class));Notifier.manager(c).cancel(Notifier.ALARM_ID);}else start(c);MainActivity.refresh();}
 private void quiet(){if(player!=null){try{player.stop();}catch(Exception ignored){}player.release();player=null;}if(vibrator!=null)vibrator.cancel();playing="";if(lock!=null&&lock.isHeld())lock.release();}
 @Override public int onStartCommand(Intent intent,int flags,int startId){JSONObject event=NativeStore.first(this);if(event==null){stopSelf();return START_NOT_STICKY;}startForeground(Notifier.ALARM_ID,Notifier.alarm(this,event));String id=event.optString("eventId");if(!NativeStore.enabled(this)||event.optBoolean("silent")){quiet();return START_STICKY;}if(!id.equals(playing)){quiet();playing=id;try{PowerManager power=(PowerManager)getSystemService(POWER_SERVICE);lock=power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"ZadaniaJulka:Alarm");lock.acquire(10*60*1000L);player=new MediaPlayer();player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());Uri sound=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);if(sound==null)sound=Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.alarm_signal);player.setDataSource(this,sound);player.setLooping(true);player.setVolume(1f,1f);player.prepare();player.start();vibrator=(Vibrator)getSystemService(VIBRATOR_SERVICE);vibrator.vibrate(VibrationEffect.createWaveform(new long[]{0,500,250,500,700},0));}catch(Exception e){try{if(player!=null)player.release();player=MediaPlayer.create(this,R.raw.alarm_signal);if(player!=null){player.setLooping(true);player.start();}}catch(Exception ignored){}}}return START_STICKY;}
 @Override public void onDestroy(){quiet();super.onDestroy();}
 @Override public IBinder onBind(Intent intent){return null;}
}
