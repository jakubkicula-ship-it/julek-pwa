package pl.zadaniajulka.app;
import com.google.firebase.messaging.*;
import org.json.JSONObject;
public class MessageService extends FirebaseMessagingService {
 @Override public void onNewToken(String token){NativeStore.prefs(this).edit().putString("fcm",token).commit();SyncJob.schedule(this);}
 @Override public void onMessageReceived(RemoteMessage message){BalanceWidget.refreshSoon(this);try{if(!NativeStore.prefs(this).getBoolean("notifications",true))return;JSONObject event=new JSONObject(message.getData());if(!event.optString("role").equals(NativeStore.object(this,"session").optString("role")))return;if("reminders".equals(event.optString("kind"))&&(event.optBoolean("requiresAck")||event.optBoolean("test"))){if(NativeStore.enqueue(this,event)){AlarmService.start(this);MainActivity.showCurrentAlert();}}else Notifier.regular(this,event);}catch(Exception ignored){}}
}
