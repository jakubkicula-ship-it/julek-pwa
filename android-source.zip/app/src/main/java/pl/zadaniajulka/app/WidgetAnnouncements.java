package pl.zadaniajulka.app;

import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class WidgetAnnouncements extends RemoteViewsService {
    private static List<JSONObject> activeRows(JSONObject state) {
        JSONArray announcements = state.optJSONArray("announcements");
        List<JSONObject> rows = new ArrayList<>();
        if (announcements == null) return rows;
        for (int i = 0; i < announcements.length(); i++) {
            JSONObject row = announcements.optJSONObject(i);
            if (row != null && !NativeStore.expired(row)) rows.add(row);
        }
        return rows;
    }

    static boolean hasRows(JSONObject state) {
        return !activeRows(state).isEmpty();
    }

    @Override public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new AnnouncementsFactory(getApplicationContext());
    }

    private static final class AnnouncementsFactory implements RemoteViewsFactory {
        private final Context context;
        private List<JSONObject> rows = new ArrayList<>();

        AnnouncementsFactory(Context context) { this.context = context; }

        @Override public void onCreate() {}

        @Override public void onDataSetChanged() {
            JSONObject state = NativeStore.object(context, "widget");
            String role = NativeStore.object(context, "session").optString("role");
            rows = !role.isEmpty() && role.equals(state.optString("role"))
                ? activeRows(state) : new ArrayList<>();
        }

        @Override public RemoteViews getViewAt(int position) {
            if (position < 0 || position >= rows.size()) return null;
            JSONObject row = rows.get(position);
            if (NativeStore.expired(row)) return null;
            RemoteViews view = new RemoteViews(context.getPackageName(), R.layout.widget_announcement);
            String date = row.optString("dueDate");
            String detail = date.isEmpty() ? row.optString("source") :
                row.optString("label") + " · " + date + " · " +
                (row.optString("subject").isEmpty() ? "" : row.optString("subject") + " · ") +
                row.optString("source");
            view.setTextViewText(R.id.widget_announcement_text, row.optString("text"));
            view.setTextViewText(R.id.widget_announcement_detail, detail);
            view.setOnClickFillInIntent(R.id.widget_announcement_row, new Intent());
            return view;
        }

        @Override public int getCount() { return rows.size(); }
        @Override public long getItemId(int position) { return position; }
        @Override public int getViewTypeCount() { return 1; }
        @Override public boolean hasStableIds() { return false; }
        @Override public RemoteViews getLoadingView() { return null; }
        @Override public void onDestroy() { rows.clear(); }
    }
}
