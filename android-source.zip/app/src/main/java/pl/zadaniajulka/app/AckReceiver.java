package pl.zadaniajulka.app;
import android.content.*;
public class AckReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent intent){String id=intent.getStringExtra("eventId");if(id!=null)AlarmService.acknowledge(c,id);} }
