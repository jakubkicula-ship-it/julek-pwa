package pl.zadaniajulka.app;
final class ReceiverPolicy {
 static String role(boolean bound,String selected){return bound?"Julek":selected;}
}
