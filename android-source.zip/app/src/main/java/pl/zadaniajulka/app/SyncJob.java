package pl.zadaniajulka.app;
import android.app.job.JobService;
import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
public class SyncJob extends JobService {
 static void schedule(Context c){JobScheduler jobs=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE);jobs.schedule(new JobInfo.Builder(7001,new ComponentName(c,SyncJob.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPersisted(true).setBackoffCriteria(30000,JobInfo.BACKOFF_POLICY_EXPONENTIAL).build());}
 @Override public boolean onStartJob(JobParameters parameters){new Thread(()->jobFinished(parameters,NativeApi.sync(this)),"julek-sync").start();return true;}
 @Override public boolean onStopJob(JobParameters parameters){return true;}
}
