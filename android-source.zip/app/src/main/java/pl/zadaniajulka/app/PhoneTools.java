package pl.zadaniajulka.app;
import android.app.*;
import android.content.*;
import android.media.AudioManager;
import android.net.*;
import android.widget.*;
final class PhoneTools {
 static boolean connected(Context c){ConnectivityManager m=(ConnectivityManager)c.getSystemService(Context.CONNECTIVITY_SERVICE);NetworkCapabilities n=m.getNetworkCapabilities(m.getActiveNetwork());return n!=null&&n.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);}
 static int alarmVolume(Context c){return ((AudioManager)c.getSystemService(Context.AUDIO_SERVICE)).getStreamVolume(AudioManager.STREAM_ALARM);}
 static int alarmMax(Context c){return ((AudioManager)c.getSystemService(Context.AUDIO_SERVICE)).getStreamMaxVolume(AudioManager.STREAM_ALARM);}
 static void volume(Activity a){AudioManager m=(AudioManager)a.getSystemService(Context.AUDIO_SERVICE);LinearLayout box=new LinearLayout(a);box.setPadding(30,20,30,20);box.setOrientation(LinearLayout.VERTICAL);TextView label=new TextView(a);label.setText("Głośność alarmów telefonu. Zmiana dotyczy również innych alarmów.");box.addView(label);SeekBar slider=new SeekBar(a);slider.setMax(alarmMax(a));slider.setProgress(alarmVolume(a));box.addView(slider);new AlertDialog.Builder(a).setTitle("Głośność alarmów").setView(box).setPositiveButton("Zapisz",(d,w)->{try{m.setStreamVolume(AudioManager.STREAM_ALARM,slider.getProgress(),0);MainActivity.refresh();}catch(Exception e){Toast.makeText(a,"Telefon nie pozwolił zmienić głośności.",Toast.LENGTH_LONG).show();}}).setNegativeButton("Anuluj",null).show();}
}
