package pl.zadaniajulka.app;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.util.Iterator;
import java.util.UUID;
final class NativeStore {
 static SharedPreferences prefs(Context c){return c.getApplicationContext().getSharedPreferences("julek-native",Context.MODE_PRIVATE);}
 static String id(Context c){String id=prefs(c).getString("id",null);if(id==null){id=UUID.randomUUID().toString().replace("-","");prefs(c).edit().putString("id",id).commit();}return id;}
 static String secret(Context c){String value=prefs(c).getString("secret",null);if(value==null){value=UUID.randomUUID().toString().replace("-","")+UUID.randomUUID().toString().replace("-","");prefs(c).edit().putString("secret",value).commit();}return value;}
 static JSONObject object(Context c,String key){try{return new JSONObject(prefs(c).getString(key,"{}"));}catch(Exception e){return new JSONObject();}}
 static void object(Context c,String key,JSONObject value){prefs(c).edit().putString(key,value.toString()).commit();}
 static boolean bound(Context c){return prefs(c).getBoolean("boundJulek",false);}
 static String receiverRole(Context c){return ReceiverPolicy.role(bound(c),object(c,"session").optString("role"));}
 static boolean enabled(Context c){return prefs(c).getBoolean("alarms",true);}
 static synchronized void session(Context c,String value){try{JSONObject next=new JSONObject(value),old=object(c,"session");if("Julek".equals(next.optString("role"))&&next.optJSONObject("preferences")!=null)object(c,"childPreferences",next.getJSONObject("preferences"));if(!next.toString().equals(old.toString())){object(c,"session",next);BalanceWidget.render(c);SyncJob.schedule(c);}}catch(Exception ignored){}}
 static synchronized boolean enqueue(Context c,JSONObject event){String id=event.optString("eventId",event.optString("id"));if(id.isEmpty()||expired(event))return false;try{event.put("eventId",id);if(!event.optBoolean("test")&&object(c,"received").has(id)){JSONObject ack=object(c,"acks");if(!ack.has(id)){event.put("pressedAt",object(c,"received").optLong(id));ack.put(id,event);object(c,"acks",ack);}SyncJob.schedule(c);return false;}JSONObject pending=object(c,"pending");if(pending.has(id)){JSONObject previous=pending.getJSONObject(id);if(!event.has("ackToken")&&previous.has("ackToken"))event.put("ackToken",previous.getString("ackToken"));}pending.put(id,event);object(c,"pending",pending);return true;}catch(Exception e){return false;}}
 static boolean expired(JSONObject event){long expiresAt=event.optLong("expiresAt");return expiresAt>0&&System.currentTimeMillis()>=expiresAt;}
 static synchronized JSONObject first(Context c){JSONObject pending=object(c,"pending"),best=null;Iterator<String> keys=pending.keys();boolean changed=false;
  while(keys.hasNext()){
   JSONObject e=pending.optJSONObject(keys.next());
   if(e==null||expired(e)){keys.remove();changed=true;continue;}
   if(best==null||e.optLong("at")<best.optLong("at"))best=e;
  }
  if(changed)object(c,"pending",pending);
  return best;}
 static synchronized void received(Context c,String id){try{JSONObject pending=object(c,"pending"),event=pending.optJSONObject(id);pending.remove(id);object(c,"pending",pending);if(event!=null&&event.optBoolean("test")){prefs(c).edit().putLong("lastTestConfirmedAt",System.currentTimeMillis()).putString("lastTestConfirmedId",id).commit();MainActivity.refresh();return;}long now=System.currentTimeMillis();JSONObject receipts=object(c,"received");receipts.put(id,now);object(c,"received",receipts);if(event!=null){event.put("pressedAt",now);JSONObject acks=object(c,"acks");acks.put(id,event);object(c,"acks",acks);}}catch(Exception ignored){}SyncJob.schedule(c);}
 static synchronized void ackSynced(Context c,String id){JSONObject acks=object(c,"acks");acks.remove(id);object(c,"acks",acks);}
}
