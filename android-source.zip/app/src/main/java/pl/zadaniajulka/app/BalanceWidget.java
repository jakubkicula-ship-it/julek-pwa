package pl.zadaniajulka.app;
import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.widget.RemoteViews;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;
public class BalanceWidget extends AppWidgetProvider {
 static boolean installed(Context c){return AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c,BalanceWidget.class)).length>0;}
 static void request(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);if(m.isRequestPinAppWidgetSupported())m.requestPinAppWidget(new ComponentName(c,BalanceWidget.class),null,null);else new AlertDialog.Builder(c).setTitle("Dodaj widżet").setMessage("Przytrzymaj puste miejsce na pulpicie telefonu, wybierz Widżety, a następnie Zadania Julka — Bilans tygodnia.").setPositiveButton("OK",null).show();}
 static void refreshSoon(Context c){if(!installed(c))return;long now=System.currentTimeMillis();if(now-NativeStore.prefs(c).getLong("widgetRequestAt",0)<60000)return;NativeStore.prefs(c).edit().putLong("widgetRequestAt",now).apply();SyncJob.schedule(c);}
 static String hours(double n){return String.format(new Locale("pl","PL"),"%s%.1f h",n>0?"+":"",n).replace(",0 h"," h");}
 static String time(long at,String format){SimpleDateFormat f=new SimpleDateFormat(format,new Locale("pl","PL"));f.setTimeZone(TimeZone.getTimeZone("Europe/Warsaw"));return f.format(new Date(at));}
 static void render(Context c){AppWidgetManager manager=AppWidgetManager.getInstance(c);JSONObject session=NativeStore.object(c,"session"),value=NativeStore.object(c,"widget");boolean valid=!session.optString("role").isEmpty()&&session.optString("role").equals(value.optString("role"));for(int id:manager.getAppWidgetIds(new ComponentName(c,BalanceWidget.class))){RemoteViews views=new RemoteViews(c.getPackageName(),R.layout.balance_widget);views.setTextViewText(R.id.widget_title,"Zadania Julka · "+(valid?value.optString("name"):"wybierz panel"));views.setTextViewText(R.id.widget_balance,valid?hours(value.optDouble("balance")):"—");views.setTextViewText(R.id.widget_today,valid?"Dzisiaj: "+hours(value.optDouble("today")):"Otwórz aplikację i wybierz osobę");double forecast=value.optDouble("forecast");views.setTextViewText(R.id.widget_forecast,valid?hours(Math.abs(forecast)).replace("+","")+(forecast<0?" do odpracowania":" na komputer"):"Bilans obecnego tygodnia");views.setTextViewText(R.id.widget_close,valid?"Rozliczenie: "+time(value.optLong("closeAt"),"EEE d.MM, HH:mm"):"");views.setTextViewText(R.id.widget_updated,valid?"Dane: "+time(value.optLong("updatedAt"),"d.MM HH:mm")+" · kliknij, aby otworzyć":"Kliknij, aby otworzyć aplikację");Intent open=new Intent(c,MainActivity.class).setAction("pl.zadaniajulka.WIDGET_HOME").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);PendingIntent click=PendingIntent.getActivity(c,7002,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);views.setOnClickPendingIntent(R.id.widget_root,click);manager.updateAppWidget(id,views);}}
 static void sync(Context c){if(!installed(c))return;try{if(NativeStore.object(c,"session").optString("role").isEmpty()){render(c);return;}JSONObject result=NativeApi.post(new JSONObject().put("action","widgetState"),NativeApi.token(c));NativeStore.object(c,"widget",result);}catch(Exception ignored){}render(c);}
 @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){render(c);SyncJob.schedule(c);}
 @Override public void onReceive(Context c,Intent intent){super.onReceive(c,intent);if(Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())){render(c);refreshSoon(c);}}
}
