package pl.zadaniajulka.app;

import android.app.AlertDialog;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RemoteViews;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class BalanceWidget extends AppWidgetProvider {
    private static int[] widgetIds(Context context, AppWidgetManager manager) {
        return manager.getAppWidgetIds(new ComponentName(context, BalanceWidget.class));
    }

    static boolean installed(Context context) {
        return widgetIds(context, AppWidgetManager.getInstance(context)).length > 0;
    }

    static void request(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        if (manager.isRequestPinAppWidgetSupported()) {
            manager.requestPinAppWidget(new ComponentName(context, BalanceWidget.class), null, null);
        } else {
            new AlertDialog.Builder(context).setTitle("Dodaj widżet")
                .setMessage("Przytrzymaj puste miejsce na pulpicie telefonu, wybierz Widżety, a następnie Zadania Julka — Bilans tygodnia.")
                .setPositiveButton("OK", null).show();
        }
    }

    static void refreshSoon(Context context) {
        if (!installed(context)) return;
        long now = System.currentTimeMillis();
        if (now - NativeStore.prefs(context).getLong("widgetRequestAt", 0) < 60000) return;
        NativeStore.prefs(context).edit().putLong("widgetRequestAt", now).apply();
        SyncJob.schedule(context);
    }

    static String hours(double value) {
        return String.format(new Locale("pl", "PL"), "%s%.1f h", value > 0 ? "+" : "", value)
            .replace(",0 h", " h");
    }

    static String time(long timestamp, String format) {
        SimpleDateFormat formatter = new SimpleDateFormat(format, new Locale("pl", "PL"));
        formatter.setTimeZone(TimeZone.getTimeZone("Europe/Warsaw"));
        return formatter.format(new Date(timestamp));
    }

    static void render(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = widgetIds(context, manager);
        if (ids.length == 0) return;
        JSONObject value = NativeStore.object(context, "widget");
        String role = NativeStore.object(context, "session").optString("role");
        boolean valid = !role.isEmpty() && role.equals(value.optString("role"));
        boolean hasAnnouncements = valid && WidgetAnnouncements.hasRows(value);
        Intent open = new Intent(context, MainActivity.class).setAction("pl.zadaniajulka.WIDGET_HOME")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent click = PendingIntent.getActivity(context, 7002, open,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        for (int id : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.balance_widget);
            views.setTextViewText(R.id.widget_title, "Zadania Julka · " + (valid ? value.optString("name") : "wybierz panel"));
            views.setTextViewText(R.id.widget_balance, valid ? hours(value.optDouble("balance")) : "—");
            views.setTextViewText(R.id.widget_today, valid ? "Dzisiaj: " + hours(value.optDouble("today")) : "Otwórz aplikację i wybierz osobę");
            double forecast = value.optDouble("forecast");
            views.setTextViewText(R.id.widget_forecast, valid
                ? hours(Math.abs(forecast)).replace("+", "") + (forecast < 0 ? " do odpracowania" : " na komputer")
                : "Bilans obecnego tygodnia");
            views.setTextViewText(R.id.widget_close, valid ? "Rozliczenie: " + time(value.optLong("closeAt"), "EEE d.MM, HH:mm") : "");
            views.setTextViewText(R.id.widget_updated, valid
                ? "Dane: " + time(value.optLong("updatedAt"), "d.MM HH:mm") + " · kliknij, aby otworzyć"
                : "Kliknij, aby otworzyć aplikację");
            views.setOnClickPendingIntent(R.id.widget_root, click);

            int height = manager.getAppWidgetOptions(id).getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT);
            int details = hasAnnouncements && height > 0 && height < 210 ? View.GONE : View.VISIBLE;
            views.setViewVisibility(R.id.widget_forecast, details);
            views.setViewVisibility(R.id.widget_close, details);
            views.setViewVisibility(R.id.widget_updated, details);
            views.setViewVisibility(R.id.widget_announcements_title, hasAnnouncements ? View.VISIBLE : View.GONE);
            views.setViewVisibility(R.id.widget_announcements, hasAnnouncements ? View.VISIBLE : View.GONE);
            if (hasAnnouncements) {
                views.setRemoteAdapter(R.id.widget_announcements, new Intent(context, WidgetAnnouncements.class));
                PendingIntent itemClick = PendingIntent.getActivity(context, 7003, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
                views.setPendingIntentTemplate(R.id.widget_announcements, itemClick);
            }
            manager.updateAppWidget(id, views);
            if (hasAnnouncements) manager.notifyAppWidgetViewDataChanged(id, R.id.widget_announcements);
        }
    }

    static void sync(Context context) {
        if (!installed(context)) return;
        try {
            if (!NativeStore.object(context, "session").optString("role").isEmpty()) {
                JSONObject result = NativeApi.post(new JSONObject().put("action", "widgetState"), NativeApi.token(context));
                NativeStore.object(context, "widget", result);
            }
        } catch (Exception ignored) {
            // The last successfully fetched board is available offline.
        }
        render(context);
    }

    @Override public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager, int id, Bundle options) {
        render(context);
    }

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        render(context);
        SyncJob.schedule(context);
    }

    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            render(context);
            refreshSoon(context);
        }
    }
}
