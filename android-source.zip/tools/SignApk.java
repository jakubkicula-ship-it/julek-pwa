import com.android.apksig.ApkSigner;
import com.android.apksig.ApkVerifier;
import java.io.*;
import java.security.*;
import java.security.cert.X509Certificate;
import java.util.*;
public class SignApk {
 public static void main(String[] args)throws Exception{char[] password=System.getenv("JULEK_SIGNING_PASSWORD").toCharArray();KeyStore keys=KeyStore.getInstance("JKS");try(InputStream in=new FileInputStream(args[1])){keys.load(in,password);}PrivateKey key=(PrivateKey)keys.getKey("julek",password);List<X509Certificate> certificates=new ArrayList<>();for(java.security.cert.Certificate certificate:keys.getCertificateChain("julek"))certificates.add((X509Certificate)certificate);ApkSigner.SignerConfig signer=new ApkSigner.SignerConfig.Builder("julek",key,certificates).build();new ApkSigner.Builder(Collections.singletonList(signer)).setInputApk(new File(args[0])).setOutputApk(new File(args[2])).setMinSdkVersion(26).setV1SigningEnabled(true).setV2SigningEnabled(true).setV3SigningEnabled(true).build().sign();ApkVerifier.Result result=new ApkVerifier.Builder(new File(args[2])).build().verify();if(!result.isVerified())throw new Exception("APK signature verification failed: "+result.getErrors());System.out.println("APK signed and verified (v2="+result.isVerifiedUsingV2Scheme()+", v3="+result.isVerifiedUsingV3Scheme()+")");}
}
